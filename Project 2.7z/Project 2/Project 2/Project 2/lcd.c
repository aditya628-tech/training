#include "lcd.h"
#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
#include <avr/interrupt.h>
#define rs_high() PORTD |=(1<<0)
#define rs_low() PORTD &= ~(1<<0)
#define en_high() PORTD |= (1<<1)
#define en_low() PORTD &= ~(1<<1)
#define lcdport PORTB
void lcd_command(unsigned char cmd);
void lcd_data(unsigned char data);
void lcd_init();
void cursorpos(char x, char y);
void lcd_out(char x, char y, char *str);



int LCDmain(void)
{
	DDRB=0xff;
	PORTD|=(1<<6);
	DDRB |= (1<<3);
	DDRC|=(1<<4);            //port C.4 as output
	lcd_init();
	while(1)
	{
		lcd_out(1,5,"Skill-lync");
		PORTD |= (1<<6);
		break;
	}
}



void lcd_command(unsigned char cmd)
{



	lcdport = cmd;
	rs_low();
	en_high();
	_delay_ms(1);
	en_low();
}



void lcd_data(unsigned char data)
{



	lcdport = data;
	rs_high();
	en_high();
	_delay_ms(1);
	en_low();
}



void lcd_init()
{
	lcd_command(0x38);_delay_ms(5);
	lcd_command(0x02);_delay_ms(5);
	lcd_command(0x01);_delay_ms(5);
	lcd_command(0x0c);_delay_ms(5);
	lcd_command(0x06);_delay_ms(5);
	lcd_command(0x80);_delay_ms(5);
}



void cursorpos(char a, char b)
{



		if(a == 1)
		{
			lcd_command(0x80 + b);
		}
		if(a == 2)
		{
			lcd_command(0xc0 + b);
		}
	
}



void lcd_out(char x,char y,char *str)
{
	cursorpos(x,y);
	while(*str)
	{
		lcd_data(*str);
		str++;
	}
}