#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

char seven_seg[10] = {0X3F, 0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F};//Array for displaying values

int SevSegDis(int portNum)//Function for seven segment display
{
	int i=0;
	switch(portNum)
	{
		case 1:
		DDRA = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTA = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 2:
		DDRB = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTB = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 3:
		DDRC = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTC = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 4:
		DDRD = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTD = seven_seg[i];
			_delay_ms(500);
		}
		break;
	}
}
