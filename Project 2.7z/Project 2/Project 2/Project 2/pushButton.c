#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
void selectPushButton(int portNum,int inpNum)
{
	switch(portNum)
	{
		case 1:
		
		DDRC |= (1<<3);
		DDRA &= ~(1<<inpNum);
		PORTA |= (1<<inpNum);
		while(1)
		{
			if(PINA & 0x01)
			PORTC |= (1<<3);
			else
			PORTC &= ~(1<<3);
			
		}
		break;
		
		case 2:
		DDRC |= (1<<3);
		DDRB &= ~(1<<inpNum);
		PORTB |= (1<<inpNum);
		while(1)
		{
			if(PINB & 0x01)
			PORTC |= (1<<3);
			else
			PORTC &= ~(1<<3);
			
		}
		break;
		
		case 3:
		DDRC |= (1<<3);
		DDRC &= ~(1<<inpNum);
		PORTC |= (1<<inpNum);
		while(1)
		{
			if(PINC & 0x01)
			PORTC |= (1<<3);
			else
			PORTC &= ~(1<<3);
			
		}
		break;
		
		case 4:
		DDRC |= (1<<3);
		DDRD &= ~(1<<inpNum);
		PORTD |= (1<<inpNum);
		while(1)
		{
			if(PIND & 0x01)
			PORTC |= (1<<3);
			else
			PORTC &= ~(1<<3);
			
		}
		break;
	}
}
