#ifndef MOTOR_H_
#define MOTOR_H_

void motorSelect(int portNum, int pinNum);


#endif /* MOTOR_H_ */