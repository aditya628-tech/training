#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

void motorSelect(int portNum, int pinNum)
{
	switch(portNum)
	{
		case 1:
		DDRA |= (1<<pinNum);
		PORTA |= (1<<pinNum);
		break;
		
		case 2:
		DDRB |= (1<<pinNum);
		PORTB |= (1<<pinNum);
		break;
		
		case 3:
		DDRC |= (1<<pinNum);
		PORTC |= (1<<pinNum);
		break;
		
		case 4:
		DDRD |= (1<<pinNum);
		PORTD |= (1<<pinNum);
		break;
	}
}