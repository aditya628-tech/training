//This is the main file. It links all other files and functions
#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
#include "lcd.h"
#include "sevenSegment.h"
#include "motor.h"
#include "portSelect.h"
#include "pushButton.h"

int main(void)
{
	while(1)
	{
		portSelect(3, 4);//Select port number(1 for port a, 2 for port b, 3 for port c and 4 for port d) and pin number (0 to 7)
		LCDmain();//calling lcd printing function
		motorSelect(4,7); //Select port number(1 for port a, 2 for port b, 3 for port c and 4 for port d) and pin number (0 to 7) for the motor
		selectPushButton(3, 0);
		SevSegDis(1);//Select port number: 1 for port a, 2 for port b, 3 for port c and 4 for port d
		
		_delay_ms(500);
	}
	
}

