

#ifndef PUSHBUTTON_H_
#define PUSHBUTTON_H_



void selectPushButton(int portNum,int inpNum);

#endif /* PUSHBUTTON_H_ */