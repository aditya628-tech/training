#ifndef SEVENSEGMENT_H_
#define SEVENSEGMENT_H_

int SevSegDis(int portNum);

#endif /* SEVENSEGMENT_H_ */