#ifndef PORTSELECT_H_
#define PORTSELECT_H_
void portSelect(int portNum, int pinNum);
#endif /* PORTSELECT_H_ */