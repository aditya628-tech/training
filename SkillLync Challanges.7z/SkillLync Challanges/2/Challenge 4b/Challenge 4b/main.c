/*
 * Challenge 4b.c
 *
 * Created: 20-09-2022 20:28:35
 * Author : aditchar
 */

#include <avr/io.h>
#define F_CPU 8000000L
#include <util/delay.h>

void T0delay()
{
	TCNT1L = 0x7F;
	TCNT1H = 0xC1; /* Load TCNT0*/
	TCCR1B = 0x01;		/* Timer0, normal mode, no pre-scalar */
						/*
						Calculation:
						Delay = (max value - value)/clock frequency
						max value = 65535(16bit counter), delay = 2ms, clock frequency = 8Mhz
						value = 45935(decimal)
							  = C17F(hexa)
						*/
}

int main(void)
{
	DDRB = 0x0F; /* PORTB as output */
	PORTB = 0x0F;
	while (1) /* Repeat forever */
	{
		PORTB = ~PORTB;
		T0delay();
	}
}
