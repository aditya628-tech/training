/*
 * Project 1.c
 *
 * Created: 19-09-2022 19:49:02
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

char seven_seg[10] = {0X3F, 0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F};

int main(void)
{
    DDRC = 0XFF; //Set port c as output
	DDRA = 0XFF; //Set port a as output
	int i=0;
	int j=0;
    while (1) 
    {

		PORTA = seven_seg[i];
		PORTC = seven_seg[j];
	    for(i=0; i<10; i++)
		{
			PORTC = seven_seg[i];
			for(j=0; j<10; j++)
			{
				PORTA = seven_seg[j];
				_delay_ms(500);	
			}
		}
		
    }
}

