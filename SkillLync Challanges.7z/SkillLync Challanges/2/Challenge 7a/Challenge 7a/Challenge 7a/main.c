/*
 * Challenge 7a.c
 *
 * Created: 21-09-2022 20:35:03
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 8000000L
#define FOSC 1843200
#define Baudrate 9600
#define UBRR ((FOSC/(16*Baudrate))-1)
#include <util/delay.h>

void Uart_Init()
{
	//Set baud rate
	UBRR0H = UBRR>>8;
	UBRR0L = UBRR;
	//ENABLE Tx
	UCSR0B = 1<<TXEN0;
	UCSR0C = 0x06;
}

int main(void)
{
	unsigned char name[20] = "Aditya Chari ";
	unsigned int i=0;
	Uart_Init();
	while (1)
	{
			while(name[i]!=0)
			{
				while (!( UCSR0A & (1<<UDRE0)));
				UDR0 = name[i];
				i++;
				_delay_ms(500);
			}
		
	}
}


