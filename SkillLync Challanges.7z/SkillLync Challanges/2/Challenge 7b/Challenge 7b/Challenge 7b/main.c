/*
 * Challenge 7b.c
 *
 * Created: 22-09-2022 14:41:37
 * Author : aditchar
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

