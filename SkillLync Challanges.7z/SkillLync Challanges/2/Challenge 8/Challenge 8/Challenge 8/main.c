/*
 * Challenge 8.c
 *
 * Created: 21-09-2022 18:09:23
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#define FOSC 1843200
#define Baudrate 9600
#define UBRR ((FOSC/(16*Baudrate))-1)
#include <util/delay.h>



char Uart_Read()
{
	int num;
	num=(int)UDR0; //typecasting to int
	char ch;
	if(num>=97 && num<=122)//Check for ASCII value of the lower case alphabet
	{
		num=num-32;//If it is lower case, convert to upper case
	}
	ch=(char)num;
	return ch;
}



Uart_Write(char a)
{
	UDR0=a;// writing the character
	_delay_ms(500);
}
void Uart_Init()
{
	//Set baudrate
	UBRR0H=UBRR>>8;
	UBRR0L=UBRR;
	//enable Tx
	UCSR0B=(1<<TXEN0)|(1<<RXEN0);
	UCSR0C=(1<<UCSZ01)|(1<<UCSZ00);
}



int main(void)
{
	char data;
	Uart_Init();//Initializing the uart connection
	while(1)
	{
		data=Uart_Read();//calling the read function
		Uart_Write(data);//calling the write funcion
	}
	return 0;
}
