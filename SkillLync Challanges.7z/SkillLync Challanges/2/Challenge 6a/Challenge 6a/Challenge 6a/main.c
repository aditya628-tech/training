/*
 * Challenge 6a.c
 *
 * Created: 20-09-2022 15:00:06
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
#define lcdport PORTB//Define port b as the datalines named as lcdport
#define rs_high PORTD |= (1<<0)//DEFINE REG SELECTOR HIGH BY SETTING THE CORRESPONDING BIT
#define rs_low PORTD &= ~(1<<0)//DEFINE REG SELECTOR LOW BY CLEARING THE CORRESPONDING BIT
#define en_high PORTD |= (1<<2)//DEFINE ENABLE HIGH BY SETTING THE CORRESPONDING BIT
#define en_low PORTD &= ~(1<<2)//DEFINE ENABLE LOW BY CLEARING THE CORRESPODING BIT

void lcd_cmd(unsigned char cmd)//CREATE A FUNCITON FOR LCD COMMAND
{
	lcdport = cmd;
	rs_low;
	en_low;
	_delay_ms(1);
	en_high;
}

void lcd_data(unsigned char data)//CREATE A FUNCTION FOR LCD DATA
{
	lcdport = data;
	rs_high;
	en_low;
	_delay_ms(1);
	en_high;
}

void setCursor(char a, char b)
{
	if(a == 1)
	{
		lcd_cmd(0x80 + b);
	}
	if(a == 2)
	{
		lcd_cmd(0xc0 + b);
	}
}

void lcd_init()
{
	lcd_cmd(0x38);_delay_ms(5);
	lcd_cmd(0x02);_delay_ms(5);
	lcd_cmd(0x01);_delay_ms(5); 
	lcd_cmd(0x0c);_delay_ms(5);
	lcd_cmd(0x06);_delay_ms(5);
	setCursor(1, 4);_delay_ms(5);
}

void lcd_init1()
{
	lcd_cmd(0x38);_delay_ms(5);
	lcd_cmd(0x02);_delay_ms(5);		
	//lcd_cmd(0x01);_delay_ms(5); 
	lcd_cmd(0x0c);_delay_ms(5);
	lcd_cmd(0x06);_delay_ms(5);
	lcd_cmd(0xc0);
}

int main(void)
{
	DDRB = 0xff;//SET DATA DIRECTION REG DDRB AS OUTPUT
	DDRD |= (1<<0);//SET DATA DIRECTION REG DDRD0 AS OUTPUT
	DDRD |= (1<<2);//SET DATA DIRECTION REG DDRD2 AS OUTPUT
	lcd_init();//INITIALISE LCD
	lcd_data('A');//CALL LCD DATA FUNCTION
	lcd_data('d');
	lcd_data('i');
	lcd_data('t');
	lcd_data('y');
	lcd_data('a');
	lcd_init1();
	lcd_data('C');
	lcd_data('h');
	lcd_data('a');
	lcd_data('r');
	lcd_data('i');
}


