/*
 * Challenge 4e.c
 *
 * Created: 20-09-2022 21:25:10
 * Author : aditchar
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

