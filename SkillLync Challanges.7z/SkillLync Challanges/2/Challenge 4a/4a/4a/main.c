/*
 * 4a.c
 *
 * Created: 20-09-2022 18:19:36
 * Author : aditchar
 */

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

void T0delay()
{
	TCNT0 = 0x5F;  /* Load TCNT0*/
	TIFR0 = 0x00;  /* Timer0, normal mode, no pre-scalar */
				   /*
				   Calculation:
				   delay = (max value - value)/clock frequency
				   for 10us delay:
				   max value = 255, clock frequency = 16Mhz. find value
				   value = 255 - (delay*clock frequency)
						 = 255 - (10u * 16M)
						 = 255 - 160
						 = 95(Decimal)
						 = 5F(Hexadecimal)
				   */

}

int main(void)
{
	DDRB = 0xFF; /* PORTB as output */
	PORTB = 0;
	while (1) /* Repeat forever */
	{
		PORTB = ~PORTB;
		T0delay();
	}
}
