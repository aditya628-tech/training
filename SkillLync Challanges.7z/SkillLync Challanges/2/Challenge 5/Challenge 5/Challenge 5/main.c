/*
 * Challenge 5.c
 *
 * Created: 21-09-2022 19:01:32
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
#include <avr/interrupt.h>

int main(void)
{
	DDRC |= (1<<5);
	DDRC |= (1<<4);            //port C.4 as output
	PORTC |= (1<<5);
	sei();                   //enable gloBal interrupt
	GICR=(1<<7)|(1<<6);     //enable INT0 and INT1
	PORTD=(1<<2)|(1<<3);    //enable pullup register
	unsigned int B=0;
	
	while(1)
	{
		PORTC &= ~(1<<5); //Port c is made high
	}

}
ISR(INT0_vect)//calling interrupt service routine
{
	PORTC|=(1<<4);
}
ISR(INT1_vect)
{
	PORTC &= ~(1<<4);
}


