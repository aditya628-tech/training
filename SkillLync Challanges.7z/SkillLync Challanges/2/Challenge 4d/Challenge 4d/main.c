/*
 * Challenge 4d.c
 *
 * Created: 20-09-2022 21:02:07
 * Author : aditchar
 */

#include <avr/io.h>
#define F_CPU 8000000L

int main(void)
{

	TCCR1B = 0b00000100; // Prescaler set to 256 since required frequency is 31.25kHz
	TCCR1A = 0b00000001; // Select waveform generation mode
	TCCR1B |= (1 << 3);

	OCR1A = 192; // For 75% duty cycle

	TCCR1A |= (1 << 7);
	DDRB = 0XFF;
}
