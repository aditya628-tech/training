//This is the main file. It links all other files and functions
#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>
#include "lcd.h"

char seven_seg[10] = {0X3F, 0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F};//Array for displaying values

void motorSelect(int portNum, int pinNum)
{
	switch(portNum)
	{
		case 1:
		DDRA |= (1<<pinNum);
		PORTA |= (1<<pinNum);
		break;
		
		case 2:
		DDRB |= (1<<pinNum);
		PORTB |= (1<<pinNum);
		break;
		
		case 3:
		DDRC |= (1<<pinNum);
		PORTC |= (1<<pinNum);
		break;
		
		case 4:
		DDRD |= (1<<pinNum);
		PORTD |= (1<<pinNum);
		break;
	}
}

void SevSegDis(int portNum)//Function for seven segment display
{
	int i=0;
	switch(portNum)
	{
		case 1:
		DDRA = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTA = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 2:
		DDRB = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTB = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 3:
		DDRC = 0XFF;
		for(i=0; i<10; i++)
		{
			PORTC = seven_seg[i];
			_delay_ms(500);
		}
		break;
		
		case 4:
		DDRD = 0XFF;
		for(i=0; i<10; i++)
	    {
			PORTD = seven_seg[i];
			_delay_ms(500);
		}

		break;
	}
}


void portSelect(int portNum, int pinNum)//function to select given port as output
{
	switch(portNum)
	{
		case 1:
			DDRA |= (1<<pinNum);
			PORTA |= (1<<pinNum);
			break;
			
		case 2:
			DDRB |= (1<<pinNum);
			PORTB |= (1<<pinNum);
			break;
		
		case 3:
			DDRC |= (1<<pinNum);
			PORTC |= (1<<pinNum);
			break;
		
		case 4:
			DDRD |= (1<<pinNum);
			PORTD |= (1<<pinNum);
			break;
	}
}



int main(void)
{
	

	while(1)
	{
		portSelect(3, 3);//Select port number
		LCDmain();
		motorSelect(4,7); //selecting port as D and pin 7
		SevSegDis(1);//Select port number: 1 for port a, 2 for port b, 3 for port c and 4 for port d
		
		
		
		_delay_ms(500);
	}
	
}

