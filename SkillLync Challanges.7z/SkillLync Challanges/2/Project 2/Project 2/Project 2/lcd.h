#ifndef LCD_H_//This is the header file definition for the lcd file
#define LCD_H_

int LCDmain(void);

#endif