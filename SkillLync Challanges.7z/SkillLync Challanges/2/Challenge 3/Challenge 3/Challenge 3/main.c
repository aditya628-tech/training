/*
 * Challenge 3.c
 *
 * Created: 19-09-2022 21:31:07
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>



int main(void)
{
	DDRB &= ~(1<<1);
	DDRC |= (1<<5);
	PORTB |= (1<<1);
	while (1)
	{
		if (!(PINB & 0X02))
		{
			PORTC |= (1 << 5);
			_delay_ms(5000);
		}
		else
		{
			PORTC &= ~(1<<5);
		}
	}
}

