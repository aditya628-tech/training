#include <stdio.h>

typedef struct
{

    int marks; // student marks

    char name[50]; // student name

} student;

void main()

{

    int n;
    printf("Enter the number of students: \n");
    scanf("%d", &n); // number of student in class

    student s[n]; // This line is to create instance of student

    printf("Enter the student detail\n");

    for (int i = 0; i < n; i++)
    {

        scanf("%d", &s[i].marks);

        scanf("%s", s[i].name); // This loop is used to input the details of the student
    }

    printf("The students who have scored more than 75 :");

    for (int i = 0; i < n; i++)
    {

        if (s[i].marks >= 75)
        { // This condition checks which student has more than 75 marks and prints

            printf("%d  ", s[i].marks);

            printf("%s  ", s[i].name);
            printf("\n");
        }
    }
}