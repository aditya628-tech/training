#include <stdio.h>

typedef struct
{

    int itemno; // itemno

    int pr_kg; // price per kg

    char item[50]; // item name

} store;

void main()

{

    int n;
    printf("Enter the number of items: \n");
    scanf("%d", &n); // number of student in class

    store s[n]; // Creating instance of student

    printf("Enter the item detail\n");

    for (int i = 0; i < n; i++)
    {

        scanf("%d", &s[i].itemno);

        scanf("%d", &s[i].pr_kg);

        scanf("%s", s[i].item);
    }

    int bill = 0;

    printf("Enter no of item to be added to the list");

    int purchasing_item;

    scanf("%d", &purchasing_item);

    for (int j = 0; j < purchasing_item; j++)
    {

        int i, p;

        printf("Enter the item to be added and the quantity in kg \n");

        scanf("%d %d", &i, &p);

        for (int j = 0; j < n; j++)
        {

            if (i == s[j].itemno)
            {

                bill = bill + (p * s[j].pr_kg);
            }
        }
    }

    printf("Your bill is %d", bill);
}