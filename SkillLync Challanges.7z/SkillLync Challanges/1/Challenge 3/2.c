#include <stdio.h>

typedef struct
{

    int emarks; // student english marks

    int smarks; // student science marks

    int mmarks; // student math marks

    char name[50]; // student name

} student;

void main()

{

    int n;
    printf("Enter number of students: \n");
    scanf("%d", &n); // number of student in class

    student s[n]; // Creating instance of student

    printf("Enter the student detail\n");

    for (int i = 0; i < n; i++)
    {

        scanf("%d", &s[i].emarks);

        scanf("%d", &s[i].smarks);

        scanf("%d", &s[i].mmarks);

        scanf("%s", s[i].name); // input details
    }

    int english, science, math;

    for (int i = 0; i < n; i++)
    {

        if (s[i].mmarks >= 50 && s[i].mmarks < 100)
        { // check is the student marks are greater than 50 in math

            math++;
        }

        if (s[i].emarks >= 50 && s[i].emarks < 100)
        { // check is the student marks are greater than 50 in english

            english++;
        }

        if (s[i].smarks >= 50 && s[i].smarks <= 100)
        { // check is the student marks are greater than 50 in science

            science++;
        }
    }

    english = (english * 100) / n; // Calculate pass percentage

    science = (science * 100) / n;

    math = (math * 100) / n;

    printf("Pass percentage of English %d Science %d Math %d\n", english, science, math);
}