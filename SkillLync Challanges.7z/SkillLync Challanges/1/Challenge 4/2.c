    #include <stdio.h>
    #include <stdlib.h>
    int main(int argc, char *argv[])
    {
        int n = atol(argv[1]); // This line takes the command line argument given by the user.
        int result = fact(n);
        printf("The factorial of %d is %d", n, result);
    }
    int fact(int n)
    {
        if (n >= 1)
        {
            return n * fact(n - 1);
        }
        else
            return 1;
        // This function claculates the factorial of the given number.
    }
