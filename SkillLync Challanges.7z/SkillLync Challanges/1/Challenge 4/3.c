#include <stdio.h>
int main()
{
    FILE *fp;
    int number, quantity, i;
    float price;
    char item[20];
    fp = fopen("C:\\Users\\aditchar\\OneDrive - Magna\\Desktop\\SkillLync Challanges\\Challenge 4\\Challenge4.txt", "w"); // This line is to open the file in the given location. If it is not present, it will create the file.
    printf("Enter Inventory data: \n");
    printf("Enter Item Name, Number, Price and Quantity (3 records):\n");
    for (i = 1; i <= 3; i++)
    {
        fscanf(stdin, "%s %d %f %d", item, &number, &price, &quantity);
        fprintf(fp, "%s %d %0.2f %d\n", item, number, price, quantity);
    }
    // The above block of code is to enter the inventory details into the text file.
    fclose(fp);
    fprintf(stdout, "\n\n");
    fp = fopen("C:\\Users\\aditchar\\OneDrive - Magna\\Desktop\\SkillLync Challanges\\Challenge 4\\Challenge4.txt", "r");
    printf("Name\tNumber\tPrice\tQuantity\n");
    for (i = 1; i <= 3; i++)
    {
        fscanf(fp, "%s %d %f %d\n", item, &number, &price, &quantity);
        fprintf(stdout, "%s\t%d\t%f\t%d\n", item, number, price, quantity);
    }
    // The above block of code is to read the inventory details from the text file and to print it into the console.
    fclose(fp);

    return 0;
}
