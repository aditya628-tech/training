#include <stdio.h>
int main()
{
    int a = 0, e = 0, i = 0, o = 0, u = 0, n; // Initializing counters for all vowels
    int len = 0, count;                       // Initializing counters to calculate length of the string
    char str[50];
    printf("Enter the string: \n");
    gets(str);
    for (count = 0; str[count] != '\0'; ++count)
        len++; // Calculating the length of the string
    for (n = 0; n < len; n++)
    {
        if (str[n] == 'a')
            a++;
        else if (str[n] == 'e')
            e++;
        else if (str[n] == 'i')
            i++;
        else if (str[n] == 'o')
            o++;
        else if (str[n] == 'u')
            u++;
    } // calculating the count of all the vowels in the string
    if (a && e && i && o && u)
        printf("All vowels present.");
    else
        printf("All vowels not present.");

    return 0;
}