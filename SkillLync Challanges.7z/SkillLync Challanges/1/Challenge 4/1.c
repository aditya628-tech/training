#include <stdio.h>
int and_func(int a, int b) { return a & b; }
int or_func(int a, int b) { return a | b; }
int xor_func(int a, int b) { return a ^ b; }
int not_func(int a, int b) { return ~a; }
// These are the separate functions that are to be called.

int main()
{
    int a, b, choice, result;
    int (*ope[4])(int, int); // This line decalare ope as function pointer array.
    ope[0] = and_func;
    ope[1] = or_func;
    ope[2] = xor_func;
    ope[3] = not_func;
    // The above lines declare each value of the array as a function.
    printf("Enter the two numbers upon which the operation is to be performed: \n");
    scanf("%x %x", &a, &b);
    printf("Enter the operation to be done: 0 for AND, 1 for OR, 2 for XOR and 3 for NOT. \n");
    scanf("%x", &choice);
    result = ope[choice](a, b); // As the function pointer is an array, this line choses the appropriate function value depending on the choicd of the user.
    printf("The result is: %x", result);
}