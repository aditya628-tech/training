#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct node
{
    int data;
    struct node *next;
} Node;

// Defining the functions
Node *insert_node(Node *head_ref, int n);
void display_list(Node *head_ref);

static Node *head1, *newnode, *tail, *head2;
static Node *head2;
int main()
{
    int list1_nos = 0, list1_items = 0, list2_nos = 0, list2_items = 0, i;

    printf("Enter the number of nodes in the list 1: \n");
    fflush(stdout);
    scanf("%d", &list1_nos);
    printf("Enter the number of nodes in the list 2: \n");
    fflush(stdout);
    scanf("%d", &list2_nos);

    printf("Enter the node elements for list 1: \n");

    for (i = 0; i < list1_nos; i++)
    {
        fflush(stdout);
        scanf("%d", &list1_items);
        head1 = insert_node(head1, list1_items);
    }

    printf("Enter the node elements for list 2: \n");

    for (i = 0; i < list2_nos; i++)
    {
        fflush(stdout);
        scanf("%d", &list2_items);
        head2 = insert_node(head2, list2_items);
    }

    
}

struct node *insert_node(struct node *head_ref, int info)
{
    struct node *temp = head_ref;
    struct node *newnode;
    newnode = malloc(sizeof(struct node));
    newnode->data = info;
    newnode->next = NULL;
    if (head_ref == NULL)
        return newnode;
    while (head_ref->next != NULL)
        head_ref = head_ref->next;
    head_ref->next = newnode;

    return temp;
}

void display_list(Node *head_ref)
{
    if (head_ref == 0)
        printf("List is empty. \n");
    else
    {
        tail = head_ref;
        while (tail != 0)
        {
            printf("%d ", tail->data); // Prints data of the current node
            tail = tail->next;         // Advances the position of the current node
        }
    }
}
