#include <stdio.h>
#include <stdlib.h>

typedef struct node // defining the structure
{
    int data;
    struct node *next;
} Node;

static Node *head1, *head2, *head, *head_union, *head_intersection, *newnode, *tail, *res_union, *res_intersection; // Declaring variables
// Function Declarations

// Defining all the required functions
void display_list(Node *head_ref) // function used to dispaly the nodes data .
{
    if (head_ref == 0)
    {
        printf(" List is empty.");
    }
    else
    {
        tail = head_ref; // we are transfering address if the list to tail
        while (tail != 0)
        {
            printf("%d ", tail->data); // prints the data of current node
            tail = tail->next;         // advances the position of current node
        }
        tail = newnode;
    }
}

Node *insert_node(Node *head_ref, int n) // Function to create new list
{
    newnode = (Node *)malloc(sizeof(Node)); // Allocate memory to new node
    newnode->data = n;                      // Assign value to the nodes
    newnode->next = head_ref;
    head_ref = newnode;
    /*Transfering the address of new node to head_ref*/
    return head_ref;
}

int compare(Node *head, int data)
{
    while (head != NULL)
    {
        if (head->data == data) // To compare data in list 1 and list 2
            return 1;
        head = head->next;
    }
    return 0;
}

Node *findUnion(Node *head_pointer1, Node *head_pointer2) // Function to find Union of the two lists
{
    while (head_pointer1 != 0)
    {
        head_union = insert_node(head_union, head_pointer1->data); // Pass data of 1st list to the union list
        head_pointer1 = head_pointer1->next;
    }
    while (head_pointer2 != 0)
    {
        if (!compare(head_union, head_pointer2->data))                 // Compare the data in list to to the data present in the union. If the data from list to is not in the union list, append the data to the union list.
            head_union = insert_node(head_union, head_pointer2->data); // Copying elements not present in the union list
        head_pointer2 = head_pointer2->next;
    }
    return head_union;
}

Node *findIintersection(Node *head_pointer1, Node *head_pointer2) // Function to find the intersection of the two unions
{
    while (head_pointer1 != 0)
    {
        if (compare(head_pointer2, head_pointer1->data))
            head_intersection = insert_node(head_intersection, head_pointer1->data);
        /*Compare the data in the two lists. If any data is found to be equal, copy that data to the intersection list.*/
        head_pointer1 = head_pointer1->next;
    }

    return head_intersection;
}

int main()
{

    int list1_nodes = 0, list2_nodes = 0, list1_items = 0, list2_items = 0;
    int f;
    printf("Enter the number of elements in first List:\n");
    fflush(stdout);
    scanf("%d", &list1_nodes);
    printf("Enter %d the elements:\n", list1_nodes); // getting the number of element in the lists
    for (f = 0; f < list1_nodes; f++)
    {
        fflush(stdout);
        scanf("%d", &list1_items);
        head1 = insert_node(head1, list1_items);
    }
    // The above loop takes data from the user and stores it in the list1.
    printf("\nEnter the number of elements in second List:\n");
    fflush(stdout);
    scanf("%d", &list2_nodes);
    printf("Enter %d the elements:\n", list2_nodes);
    for (f = 0; f < list2_nodes; f++)
    {
        fflush(stdout);
        scanf("%d", &list2_items);
        head2 = insert_node(head2, list2_items);
    }
    // The above loop takes data from the user and stores it in the list2.
    res_union = findUnion(head1, head2); // Finding the union of the two lists and storing it to another variable
    printf("The union of the two linked lists is: \n");
    display_list(res_union);
    printf("\n");

    res_intersection = findIintersection(head1, head2);
    printf("The intersection of the two linked lists is: \n"); // Finding the intersection of the two lists and storing it to another variable
    display_list(res_intersection);
}
