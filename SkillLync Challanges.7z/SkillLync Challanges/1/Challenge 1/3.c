#include <stdio.h>
int main()
{
   int num, pos;
   printf("Enter a number\n");
   scanf("%d", &num);
   printf("Binary form: ");
   for (pos = 15; pos >= 0; pos--)  // for 16 bits. For 32 bit, change pos to 31 and for 8 bits change pos to 7
      printf("%d", num >> pos & 1); // Right shift the number by the bits required.
}