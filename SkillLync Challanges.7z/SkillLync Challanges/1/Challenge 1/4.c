#include <stdio.h>
void main()
{
    int n = 0x0214;        // Take a hexadecimal number
    n = n ^ (0x0200 >> 4); // Bring the 9th bit to 5th position
    n = n ^ (0x0020 << 4); // Bring the 5th bit to 9th position
    printf("0x00%x", n);
}
