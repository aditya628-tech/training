#include <stdio.h>
int main()
{
    char character;
    printf("Enter the character: \n");
    scanf("%c", &character); // Take input from user.
                             // Check ascii value of the character. The given ascii values in the condition statements are the ascii values for the character types to be checked for
    if (character >= 65 && character <= 90)
        printf("%c is Upper case alphabet.\n", character);

    else if (character >= 97 && character <= 122)
        printf("%c is lower case alphabet.\n", character);

    else if (character >= 48 && character <= 57)
        printf("%c is a number.\n", character);

    else
        printf("%c is a special character.\n", character);

    return 0;
}