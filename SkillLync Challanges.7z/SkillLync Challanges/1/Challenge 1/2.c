#include <stdio.h>
void main()
{
    int salvage = 2000, machine_cost = 6000, earning_per_year = 1000, i, year = 0;
    i = 6000 * 1 * 0.09; // Calculate 9% interest
    while (salvage <= machine_cost)
    {
        // This loop checks the profit values in each year for both the machine and the alternate investment and checks which year is more profitable. When the machine cost is more profitable, the loop exits
        salvage = salvage + earning_per_year;
        machine_cost = machine_cost + i;
        year++;
    }
    printf("In year %d the earnings from machine is more than earning from alternative inverstments\n", year);
    printf("Earnings from machine: %d\n", salvage);
    printf("Earning from alternative investments: %d\n", machine_cost);
}