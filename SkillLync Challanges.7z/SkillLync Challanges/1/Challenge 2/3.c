#include <stdio.h>
int main()
{
  int a[20], EvenCount = 0, OddCount = 0, i, n;
  printf("Enter array size: ");
  scanf("%d", &n); // This line takes the size of the array and stores it in the variable 'n'

  printf("Enter %d elements of an array: \n", n);
  for (i = 0; i < n; i++)
  {
    scanf("%d", &a[i]);
  } // This loop takes each element entered and puts it to the respective index of the array.
  for (i = 0; i < n; i++)
  {
    a[i] % 2 ? OddCount++ : EvenCount++; // checking num are odd or even & increasing count
  }
  printf("Number of even = %d & Number of odd = %d", EvenCount, OddCount);
}