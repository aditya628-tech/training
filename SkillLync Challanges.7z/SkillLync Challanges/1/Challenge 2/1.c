#include <stdio.h>
void main()
{
    int a[20], i, j, t, n;
    printf("Enter array size: ");
    scanf("%d", &n); // This line takes the size of the array and stores it in the variable 'n'

    printf("Enter %d elements of an array: \n", n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    } // This loop takes each element entered and puts it to the respective index of the array.
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (a[i] > a[j])
            {
                t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
    } // This for loop takes each element in the array and compares it to the other elements. If an element is found to be greater, it swaps the two elements. Thus the final array will sorted. This is an example for ascending arder. For descending order, use a[i] < a[j]
    for (i = 0; i < n; i++)
        printf("%d  ", a[i]);
}