#include <stdio.h>
int main()
{
  int arr[10], n, i, largest;

  printf("Enter array size: ");
  scanf("%d", &n); // This line takes the size of the array and stores it in the variable 'n'

  printf("Enter %d elements of an array: \n", n);
  for (i = 0; i < n; i++)
  {
    scanf("%d", &arr[i]);
  } // This loop takes each element entered and puts it to the respective index of the array.

  largest = arr[0];
  for (i = 1; i < n; i++)
  {
    if (largest < arr[i])
    {
      largest = arr[i];
    }
  } // This loop finds the largest value in the array. It uses a variable called largest and initially takes the first element of the array as its value. Then it compares the remaining elements one by one and if it finds a greater number it changes its value to that number.

  printf("The largest element is %d", largest);

  return 0;
}