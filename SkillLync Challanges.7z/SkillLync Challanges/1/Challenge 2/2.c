#include <stdio.h>

void main()
{
    int n, a[20], b[20], i, j;
    printf("Enter the array size: \n");
    scanf("%d", &n);
    printf("Enter the array elements: \n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    // The following loop is the part of the code which copies the contents of array a in to array b in reverse order.
    for (i = n - 1, j = 0; i >= 0; i--, j++)
        b[j] = a[i];
    printf("Original array: \n");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
    // The following loop displays the b array which has the same elements of a but in reverse order.
    printf("Reversed array: \n");
    for (i = 0; i < n; i++)
        printf("%d ", b[i]);
}
