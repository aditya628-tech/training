#include <stdio.h>
int main()
{
  int arr[10], n, i, largest;

  printf("Enter the array size : ");
  scanf("%d", &n);

  printf("Enter %d elements of an array: ", n);
  for (i = 0; i <= n - 1; i++)
  {
    scanf("%d", &arr[i]);
  }

  largest = arr[0];
  for (i = 1; i <= n - 1; i++)
  {
    if (largest < arr[i])
    {
      largest = arr[i];
    }
  }

  printf("The largest element is %d", largest);

  return 0;
}