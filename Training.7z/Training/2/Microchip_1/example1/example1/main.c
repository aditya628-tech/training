/*
 * example1.c
 *
 * Created: 19-09-2022 10:40:25
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

int main(void)
{
		DDRB = 0XFF;
		
    while (1) 
    {
		PORTB = 0X0F;
//		_delay_ms(1000);
		PORTB = 0XF0;
//		_delay_ms(1000);
    }
}

