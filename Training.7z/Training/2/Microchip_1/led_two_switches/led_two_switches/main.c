/*
 * led_two_switches.c
 *
 * Created: 19-09-2022 14:42:02
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

int main(void)
{
	DDRB |= (1<<3);//set b3 as output
	DDRC &= ~(1<<7);
	DDRC &= ~(1<<1);
	PORTC |= (1<<7);//internal pullup register enable
	
    while (1) 
    {
		if(!(PINC & 0X80))
			PORTB |= (1<<3);
		if(PINC & 0X02)
			PORTB &= ~(1<<3);
    }
}

