/*
 * setting_single_bit.c
 *
 * Created: 19-09-2022 11:44:51
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>


int main(void)
{
	DDRB |= (1<<3);
    while (1) 
    {
		PORTB |= (1<<3);
		_delay_ms(1000);
		PORTB &= ~(1<<3);
		_delay_ms(1000);
    }
}

