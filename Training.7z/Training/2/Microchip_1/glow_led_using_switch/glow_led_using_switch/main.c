/*
 * glow_led_using_switch.c
 *
 * Created: 19-09-2022 11:57:31
 * Author : aditchar
 */

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

int main(void)
{
	DDRC |= (1 << 7);  // set as output
	DDRB &= ~(1 << 0); // set as input
	PORTB |= (1 << 0); // Internal pull up enable.
	while (1)
	{
		if (PINB & 0X01)
		{
			PORTC |= (1 << 7);
		}
		else
		{
			PORTC &= ~(1 << 7);
		}
	}
}
