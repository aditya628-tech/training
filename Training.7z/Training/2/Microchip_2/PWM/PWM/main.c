/*
 * PWM.c
 *
 * Created: 20-09-2022 11:37:05
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L


int main(void)
{
	TCCR1B = 0b00000101;
	TCCR1A = 0b00000001;
	TCCR1B |= (1<<3);
	
	OCR1A = 50;
	/*
	Max value is 255, 50% duty cycle = 128
	75% = 192
	25% ~ 50
	*/
	TCCR1A |= (1<<7);
	DDRB = 0XFF;
}

