/*
 * square_wave.c
 *
 * Created: 20-09-2022 10:39:22
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L

int main(void)
{
	/*Setting for timer block*/
	//clock config for timer
	//prescaler set to 1024
	TCCR1B = 0b00000101;
	//waveform generation bit setting
	TCCR1A = 0b00000000;
	TCCR1B  |= (1<<3);
	//TOP SETTING
	OCR1A = 10000;
	//OC1A TOGGLE CONFIG
	TCCR1A |= (1<<6);
	DDRB = 0XFF;
	
}

