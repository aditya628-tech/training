/*
 * clock_without_prescalar.c
 *
 * Created: 20-09-2022 10:03:38
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>


int main(void)
{
	//Setting up clock source and clearing WGM02 bit
    TCCR0B = 0b00000001;
	//Clearing WGM00 &WGM01 bit
	TCCR0A &= ~((1<<1)|(1<<0));
	DDRB = 0XFF;
	//PORTB = 0XFF;
    while (TCNT0<200) 
    {
		TCNT0 = 0;
		PORTB =~(PORTB);	
    }
}

