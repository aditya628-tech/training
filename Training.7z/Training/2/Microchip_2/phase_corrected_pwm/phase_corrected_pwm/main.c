/*
 * phase_corrected_pwm.c
 *
 * Created: 20-09-2022 12:03:27
 * Author : aditchar
 */																																																																											

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

