/*
 * 2.c
 *
 * Created: 21-09-2022 10:36:59
 * Author : aditchar
 */ 

#include <avr/io.h>


int main(void)
{
	DDRC |= 0x00;
	SFIOR &= (1<<ACME);
	ACSR &= 0x00;
	while (1)
	{
		if(ACSR & (1<<ACO))
		PORTC = 0X80;
		else
		PORTC = 0X00;
	}
}
