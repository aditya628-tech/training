/*
 * serial_comm_receive.c
 *
 * Created: 21-09-2022 14:50:36
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#define FOSC 1843200
#define Baudrate 9600
#define UBRR ((FOSC/(16*Baudrate))-1)
#include <util/delay.h>

void Uart_Init()
{
	//Set baud rate
	UBRR0H = UBRR>>8;
	UBRR0L = UBRR;
	//ENABLE Tx
	UCSR0B = (1<<TXEN0)|(1<<RXEN0);
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
}

int main(void)
{
	char data;
	Uart_Init();
	while (1)
	{
		data = Uart_Read();
		Uart_Write(data);
	}
	return 0;
}

void Uart_Write(char a)
{
	UDR0 = a;
	_delay_ms(500);
}

void Uart_Read()
{
	return UDR0;
}
