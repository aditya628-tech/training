/*
 * SPI.c
 *
 * Created: 21-09-2022 15:16:38
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#include <util/delay.h>

void SPI_Master_Init()
{
	DDRB = (1<<DDB5)|(1<<DDB3)|(1<<DDB2);
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

void SPI_Master_Write()
{
	PORTB|=(1<<DDB2);
	SPDR = 0X05;
	while((SPSR&(1<<SPIF))==0);
}

int main(void)
{
    
    while (1) 
    {
		SPI_Master_Init();
		SPI_Master_Write();
    }
}

