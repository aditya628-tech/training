/*
 * serial_comm1.c
 *
 * Created: 21-09-2022 14:33:32
 * Author : aditchar
 */ 

#include <avr/io.h>
#define F_CPU 16000000L
#define FOSC 1843200
#define Baudrate 9600
#define UBRR ((FOSC/(16*Baudrate))-1)
#include <util/delay.h>

void Uart_Init()
{
	//Set baud rate
	UBRR0H = UBRR>>8;
	UBRR0L = UBRR;
	//ENABLE Tx
	UCSR0B = 1<<TXEN0;
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
}

int main(void)
{
    Uart_Init();
    while (1) 
    {
		if((UCSR0A && (1<<5))==1)//CHECK AC0 BIT OF ACSR REG
		{
			UDR0 = '2';
			_delay_ms(500);
		}
    }
}

