/*
 * adc.c
 *
 * Created: 21-09-2022 10:06:25
 * Author : aditchar
 */ 

#include <avr/io.h>

int main(void)
{
    int adc;
	DDRC = 0;
	DDRB = 0X01;
	ADMUX = 0X40;
	ADCSRA = 0X87;
    while (1) 
    {
		ADCSRA |= (1<<ADSC);
		while((ADCSRA & (1<<ADIF))==0);
		adc = (int)ADCL + (int)(ADCH*256);
		if(adc<510)
		{
			PORTB = 1;
		}
		else
			PORTB = 0;
		ADCSRA = 0X87;
    }
}

