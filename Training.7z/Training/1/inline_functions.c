// When function is very small, we can use inline functions to save space.
// It does not redirect to the function but copies the function definition to the place where the function is called