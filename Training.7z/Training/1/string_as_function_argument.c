#include <stdio.h>
void displayString(char *str)
{
    printf("String is: %s\n", str);
}

int main(void)
{
    char *msg = "Hello World";
    displayString(msg);
    return 0;
}
