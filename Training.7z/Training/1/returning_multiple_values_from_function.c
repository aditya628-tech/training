#include <stdio.h>
void func(int x, int y, int *Pd, int *Pp, float *Pm, float *Pdiv)
{
    *Pd = x - y;
    *Pp = x * y;
    *Pm = x % y;
    *Pdiv = x / y;
}
int main()
{
    int a, b, diff, prod;
    a = 8;
    b = 6;
    float mod, div;
    func(a, b, &diff, &prod, &mod, &div);
    printf("\nDifference: %d", diff);
    printf("\nProduct: %d", prod);
    printf("\nModulus: %f", mod);
    printf("\nDivision: %f", div);

    return 0;
}