#include <stdio.h>
int multiply(int a, int b)
{
    return a * b;
}

int main()
{
    int a = 10, b = 20;
    int (*func_pointer)(int, int);
    func_pointer = multiply; // Declare function pointer. & is not necessary
    printf("Without function pointer: \n");
    printf("%d\n", multiply(a, b));

    printf("With function pointer: \n");
    printf("%d", (func_pointer)(a, b));
}