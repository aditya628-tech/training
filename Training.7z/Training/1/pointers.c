#include <stdio.h>
int main()
{
    int a = 10, b = 20;
    int *p = &a;
    void *d = &b;
    printf("The value in the variable a is: %d\n", *p);
    printf("The value in the variable b is : %d", *(int *)d); // This is to dereference void pointers.
}