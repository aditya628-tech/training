#include <stdio.h>
#include <setjmp.h>
jmp_buf buf;
// void func()
// {
//     printf("Welcome to C essential course 1\n");

//     longjmp(buf, 1);
//     printf("Welcome to C essential course 2\n");
// }
int main()
{
    // Control or Conditional statements:
    // int a;
    // a = 0;
    // printf("\n Enter the value of A: ");
    // scanf("%d", &a);
    // if (a > 5)
    //     printf("\nThe value of A is greater than 5");
    // else
    //     printf("\nThe value of A is less than 5");
    //     int a = 10;
    // label:
    //     if (a)
    //         printf("%d\n", a);
    //     goto label;

    // Unconditional control Statements:

    // int x = 65;
    // switch (x)
    // {
    // case 'A':
    //     printf("working");
    //     break;

    // default:
    //     printf("Not working");
    //     break;
    // }

    // char a;
    // a = 'A';
    // switch (a)
    // {
    // case 'a':
    // case 'b':
    //     printf("Both A and a is selected");
    //     break;
    // case 'B':
    //     printf("Both A and a is selected");
    // }

    // if (setjmp(buf))
    //     printf("Welcome to C essential course 3\n");
    // else
    // {
    //     printf("Welcome to C essential course 4\n");
    //     func();
    // }

    int b = 3;
    if (setjmp(buf) != 0)
    {
        printf("%d", b);
        return 0;
    }
    b = 5;
    longjmp(buf, 1);
}