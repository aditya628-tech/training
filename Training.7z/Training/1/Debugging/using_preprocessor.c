#include <stdio.h>
#define DEBUG // if this line is commented, then all lines inside the #ifdef loops will not be compiled
int multiply(int a, int b)
{
#ifdef DEBUG
    printf("Inside multiply function: \n");
#endif
    return a * b;
}

void display(int a, int b)
{
#ifdef DEBUG
    printf("Inside display function: \n");
#endif
    int result;
#ifdef DEBUG
    printf("Calling multiply function: \n");
#endif
    result = multiply(a, b);

#ifdef DEBUG
    printf("The value of a and b is: %d, %d\n", a, b);
#endif
    printf("The result is %d", result);
}

int main()
{
#ifdef DEBUG
    printf("Calling display function from main\n");
#endif // DEBUG
    display(5, 6);
}