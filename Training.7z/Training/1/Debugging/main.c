#include <stdio.h>
int main()
{
    int sum = 0;
    int a[5] = {2, 5, 6, 8, 5};
    for (int i = 0; i < 5; i++)
        sum += a[i];
    printf("Sum of the array elements is: %d", sum);
    return 0;
}