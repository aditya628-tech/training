// Putting function pointer as argument
#include <stdio.h>
float Gain(float);
void func(float (*funptr)(float));
int main()
{
    float (*fp)(float);
    fp = Gain;
    float result;
    result = Gain(5);
    printf("\nThe result is: %f", result);
    result = (*fp)(10);
    printf("\nThe result is: %f", result);
    func(fp);
}
float Gain(float a)
{
    return a * a;
}

void func(float (*funptr)(float))
{
    float func_result;
    printf("\nFunction func is called: ");
    func_result = (*funptr)(12);
    printf("\nThe result of func() is: %f", func_result);
}