#include <stdio.h>
void display(int *num)
{
    printf("Displaying: \n");
    for (int i = 0; i < 4; i++)//Since it is a pointer, only one for loop is enough when we know the number of elements

        printf("%d\n", *num++);
}

int main()
{
    int num[2][2];
    printf("Enter 4 numbers: \n");
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
            scanf("%d", &num[i][j]);
    }
    // int *ptr = num;
    display(num); // Name of the array itself is a pointer. Hence there is no need to create a separate pointer.
    return 0;
}