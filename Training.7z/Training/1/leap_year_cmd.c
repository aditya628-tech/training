#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
    int y = atoi(argv[1]); // To convert character to integer.
    if (((y % 4) == 0) || ((y % 100) == 0))
        printf("%d is a leap year.", y);
    else
        printf("%d is not a leap year.", y);
}