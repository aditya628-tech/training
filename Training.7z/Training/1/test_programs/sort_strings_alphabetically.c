#include <stdio.h>
#include <string.h>
// void display(char arr[][30], int n)
// {
//     for (int i = 0; i < n; i++)
//     {
//         printf("%s", arr[i]);
//     }
//     printf("\n");
// }
int main()
{
    char n[20][20], temp[20];
    int num;
    printf("Enter the number of names to be added: \n");
    scanf("%d", &num);
    for (int i = 0; i < num; i++)
    {
        printf("Enter name %d: ", i + 1);
        scanf("%s", n[i]);
    }
    // display(n, num);
    
}
