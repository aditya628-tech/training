#include "sub.h"
int main()
{
    int result = 0;
    result = sub(0, 5);
    printf("The result is: %d", result);
    getchar();
    return 0;
}
