#ifndef SUB_H_INCLUDED
#define SUB_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

int sub(int, int);

#endif
