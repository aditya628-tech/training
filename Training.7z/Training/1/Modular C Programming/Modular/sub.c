#include "sub.h"
int sub(int a, int b)
{
    int result = 0;
    result = subtract(a, b);
    return result;
}
int subtract(int a, int b)
{
    return a - b;
}
