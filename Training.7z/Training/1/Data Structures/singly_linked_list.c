#include <stdio.h>
#include <stdlib.h>

// Creating the node
struct node
{
    int value;
    struct node *next;
};

// Printing linked list values:
void printLinkedList(struct node *p)
{
    while (p != NULL)
    {
        printf("Address: %d\n", p);
        printf("Value: %d\n", p->value);
        p = p->next;
    }
}

int main()
{
    // Initializing the nodes:
    struct node *head;
    struct node *one = NULL;
    struct node *two = NULL;
    struct node *three = NULL;

    // Allocating memory:
    one = malloc(sizeof(struct node));
    two = malloc(sizeof(struct node));
    three = malloc(sizeof(struct node));

    // Assigbibg values:
    one->value = 1;
    two->value = 2;
    three->value = 3;

    // Connecting the nodes:
    one->next = two;
    two->next = three;
    three->next = NULL;
    head = one;

    // Printing the node values:
    printLinkedList(head);
}