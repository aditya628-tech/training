#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
} Node;

// Defining the functions
Node *insert_node(Node *head_ref, int n);
void display_list(Node *head_ref);

static Node *head, *newnode, *tail;
int main()
{
    int nodes_nos = 0, node_items = 0;

    printf("Enter the number of nodes in the list: \n");
    fflush(stdout);
    scanf("%d", &nodes_nos);

    printf("Enter the node elements: \n");

    for (int i = 0; i < nodes_nos; i++)
    {
        fflush(stdout);
        scanf("%d", &node_items);
        head = insert_node(head, node_items);
    }

    display_list(head);
}

struct node *insert_node(struct node *head_ref, int info)
{
    struct node *temp = head_ref;
    struct node *newnode;
    newnode = malloc(sizeof(struct node));
    newnode->data = info;
    newnode->next = NULL;
    if (head_ref == NULL)
        return newnode;
    while (head_ref->next != NULL)
        head_ref = head_ref->next;
    head_ref->next = newnode;

    return temp;
}

void display_list(Node *head_ref)
{
    if (head_ref == 0)
        printf("List is empty. \n");
    else
    {
        tail = head_ref;
        while (tail != 0)
        {
            printf("%d ", tail->data); // Prints data of the current node
            tail = tail->next;         // Advances the position of the current node
        }
    }
}
