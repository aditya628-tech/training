#include <stdio.h>
int fact(int n)
{
    if (n != 1)
        return n * fact(n - 1);
    else
        return n;
}

int main()
{
    int a;
    printf("Enter the value of a: \n");
    scanf("%d", &a);
    printf("the factorial of %d is %d\n", a, fact(a));
    return 0;
}