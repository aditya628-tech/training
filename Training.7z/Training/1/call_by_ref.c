#include <stdio.h>
void swapx(int *, int *);
int main()
{
    int a = 10, b = 20, x, y;
    (x, y) = swapx(&a, &b);
    printf("a = %d, b = %d\n", a, b);
    printf("x = %d, y = %d\n", *x, *y);

    return 0;
}
void swapx(int *x, int *y)
{
    *x = *x + *y;
    *y = *x - *y;
    *x = *x - *y;
    return (*x, *y); // Homework
}