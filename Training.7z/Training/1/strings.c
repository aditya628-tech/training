#include <stdio.h>
int main()
{
    char name[20];
    printf("Enter the name: \n");
    scanf("%[^\n]", name); // or use gets(name);
    // printf("The name is: %s", name);
    puts(name);
    return 0;
}