#include <stdio.h>

struct student
{
    char Name[30];
    int RollNo;
    int age;
}

disp_student(struct student *stdptr)
{
    for (int i = 0; i < 2; i++)
    {
        printf("\nName: %s", (stdptr + i)->Name);
        printf("\nRoll Number: %d", (stdptr + i)->RollNo);
        printf("\nAge: %d", (stdptr + i)->age);
    }
}

int main()
{
    struct student st[2] = {{"ASD", 56, 89}, {"QWE", 578, 749}};
    // struct student stud1 = {"ASD", 56, 89};
    // struct student stud2 = {"QWE", 578, 749};
    disp_student(st);
}