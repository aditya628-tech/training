#include <stdio.h>
#include <string.h>
int main()
{
    char a[30], b[30];
    char *found;
    printf("Enter a string: \n");
    fflush(stdout);
    gets(a);
    printf("\nEnter the string to be searched for: \n");
    fflush(stdout);
    gets(b);
    found = strstr(a, b);
    if (found)
    {
        printf("\nFound value: %p", found);
        printf("\n%s is found in %s after %d position. ", b, a, found - a);
    }
    else
        printf("\n-1 since the string is not found.");
}