#include <stdio.h>
int main()
{
	int arr1[] = {2, 4, 6, 8, 10};
	int arr2[] = {10, 20, 30};
	int arr3[] = {1, 3};
	int *arr_arr[3], **arr_ref;
	arr_arr[0] = arr1;
	arr_arr[1] = arr2;
	arr_arr[3] = arr3;
	arr_ref = arr_arr;

	printf("By index: %d\n", arr_arr[1][1]);
	printf("By pointer: %d", *(*(arr_ref + 1) + 1));
}
