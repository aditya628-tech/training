#include <stdio.h>
#include <string.h>
int main()
{
    char a[50], b[50];
    printf("Enter a string: \n");
    fflush(stdout);
    gets(a);
    gets(b);
    strncpy(b, a, 3);
    b[3] = '\0';
    printf("\nCopied string = %s", b);
}