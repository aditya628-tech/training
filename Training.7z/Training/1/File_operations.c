// File pointers is used to access external files.
#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f; // Step 1: Create a pointer to the FILE type.
    // f = fopen("C:\\Users\\aditchar\\OneDrive - Magna\\Desktop\\Training\\files\\test1.txt", "w");
    // if (f == NULL)
    //     printf("Error");
    // else
    // {
    //     fprintf(f, "%s\n", "This is the first program in file handling.");
    //     fputc('A', f);
    //     fputs("\nDemonstration for fputs function. ", f);
    //     fclose(f);
    //     return 0;
    // }

    // The above block is for creating the file.
    f = fopen("C:\\Users\\aditchar\\OneDrive - Magna\\Desktop\\Training\\files\\test1.txt", "r"); // mode w+ can be used to perform both reading and writing.
    // char ch;
    // while (1)
    // {
    //     ch = fgetc(f);
    //     if (ch == EOF)
    //         break;
    //     printf("%c", ch);
    // }
    // printf("\nUsing fgets: ");
    char str[100];
    fgets(str, 100, f);
    printf("%s", str);
    fclose(f);
    return 0;
}