#include <stdio.h>
#include <math.h>
float sqr(int num) { return num * num; }
float sqr_root(int num) { return sqrt(num); }
float cube(int num) { return num * num * num; }
float cube_root(int num) { return cbrt(num); }

int main()
{
    int x, choice;
    float result;
    float (*ope[4])(int);
    ope[0] = sqr;
    ope[1] = sqr_root;
    ope[2] = cube;
    ope[3] = cube_root;
    printf("Enter the number: \n");
    scanf("%d", &x);
    printf("Enter the operation to be done. Enter 0 for Square, 1 for square root, 2 for cube and 3 for cube root.\n");
    scanf("%d", &choice);
    result = ope[choice](x);
    printf("The result is: %f", result);
    return 0;
}