// malloc and calloc
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int i, *ptr, sum = 0;
    // ptr = calloc(10, sizeof(int)); // Using alloc
    // Using malloc:
    ptr = (int *)malloc(40);
    // realloc:ptr = realloc(ptr, newsize);

    if (ptr == NULL)
    {
        printf("Error! memory not allocated.");
        exit(0);
    }
    printf("Default values: ");
    for (i = 0; i < 12; i++)
    {
        printf("%d  ", *(ptr + i));
    }

    printf("Building and calculating the sequence of the first 10 terms: \n");
    for (i = 0; i < 10; ++i)
    {
        *(ptr + i) = i;
        sum += *(ptr + i);
    }
    printf("Sum = %d", sum);
    free(ptr);
    return 0;
}