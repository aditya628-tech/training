#include <stdio.h>
int main(int argc, char *argv[])
{
    printf("\n Name of the program is: %s", argv[0]);
    if (argc < 2)
        printf("\n No Arguments is passed through the command line. ");
    else
        printf("\n First argument is: %s", argv[1]);
}