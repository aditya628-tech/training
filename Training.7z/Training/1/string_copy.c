#include <stdio.h>
#include <string.h>
int main()
{
    char a[50], b[50];
    printf("Enter the source string: \n");
    fflush(stdout);
    scanf("%s", a);
    printf("Enter the destination string: \n");
    fflush(stdout);
    scanf("%s", b);
    strcpy(b, a);
    printf("Copied string: %s", b);
}