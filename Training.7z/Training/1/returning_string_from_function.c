#include <stdio.h>
char *display()
{
    return "Hello World";
}

int main()
{
    char *str;
    str = display();
    printf("The string is: %s", str);
}