#include<stdio.h>
struct student
{
    char Name[10];
    int RollNo;
    int age;
};


